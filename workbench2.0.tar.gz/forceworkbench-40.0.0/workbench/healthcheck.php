<?php
require_once 'session.php';
require_once 'shared.php';
?>
OK