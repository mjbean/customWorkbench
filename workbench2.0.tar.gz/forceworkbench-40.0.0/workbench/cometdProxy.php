<?php
require_once "util/CometdProxy.php";
require_once "session.php";

CometdProxy::checkPreconditions();

$proxy = new CometdProxy();

?>
