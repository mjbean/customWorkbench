<?php
require_once 'session.php';
require_once 'shared.php';
require_once 'put.php';

put('insert');
?>
